import { Box, Typography } from '@mui/material'
import React from 'react'
import SearchBox from '../searchBox/SearchBox'

const Header = ({ searchValue, setSearchValue, setLoading, setTreeData }) => {
    return (
        <>
        <Box sx={{
             position: 'fixed', display: 'flex',
             justifyContent: 'center',
            // gap:'200px',
            alignItems: 'center',
            width:'100%',
            height: '8vh', 
            zIndex: 500, background: '#004994',
        }}>
            <Box sx={{ mx: 1 }}>
                <Typography variant='h5' color="white" style={{ marginLeft: '16px' }}>
                    MindMap
                </Typography>
            </Box>
            <Box sx={{ mx: 10 }}>
                <SearchBox style={{ marginLeftt: '16px', width:'900px' }}
                    searchValue={searchValue}
                    setSearchValue={setSearchValue}
                    setLoading={setLoading}
                    setTreeData={setTreeData}
                />
            </Box>

        </Box>
         <Box sx={{
            position: 'fixed', display: 'flex',
            top:'40px',
            justifyContent: 'center',
            gap:'40px',
           alignItems: 'center',
           width:'100%',
           height: '8vh', 
           zIndex: 500, background: '#004994',
       }}>
               <Typography variant='h7' color="white" style={{ marginLeft: '16px' }}>
                   Example Searches:
               </Typography>
               <Typography variant='h7' color="white" style={{ marginLeft: '16px' }}>
               how to begin learning network security
               </Typography>
               <Typography variant='h7' color="white" style={{ marginLeft: '16px' }}>
               how to become a certified react developer
               </Typography>
               <Typography variant='h7' color="white" style={{ marginLeft: '16px' }}>
               efficient ways to product marketing
               </Typography>
           </Box>
           </>
    )
}

export default Header